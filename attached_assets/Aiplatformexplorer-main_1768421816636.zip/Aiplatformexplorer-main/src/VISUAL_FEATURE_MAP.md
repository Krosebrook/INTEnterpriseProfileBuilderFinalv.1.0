# Visual Feature Map: AI-Powered Recommendation Engine

## 🗺️ Complete Feature Architecture

```
┌────────────────────────────────────────────────────────────────────────────┐
│                   AI PLATFORM EXPLORER (v3.2)                              │
│                                                                            │
│  ┌──────────┬──────────┬──────────┬─────────────────┬──────────┐        │
│  │🔍        │📊        │💰        │🤖               │📚        │        │
│  │Platform  │Feature   │ROI       │Get              │Glossary  │        │
│  │Explorer  │Matrix    │Calculator│Recommendation   │          │        │
│  │          │          │          │⭐ NEW!          │          │        │
│  └──────────┴──────────┴──────────┴─────────────────┴──────────┘        │
│                                                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                 🤖 RECOMMENDATION ENGINE                            │  │
│  │                                                                     │  │
│  │  ┌───────────────────────────────────────────────────────────┐    │  │
│  │  │                    WIZARD FLOW                            │    │  │
│  │  │                                                           │    │  │
│  │  │  Step 1: Welcome                                          │    │  │
│  │  │  ├─ "Get Personalized AI Platform Recommendations"        │    │  │
│  │  │  ├─ Progress: 0%                                           │    │  │
│  │  │  └─ Estimated time: 5-7 minutes                           │    │  │
│  │  │                                                           │    │  │
│  │  │  Step 2-12: Questions (11 total)                          │    │  │
│  │  │  ┌────────────────────────────────────────────┐          │    │  │
│  │  │  │ QUESTION CARD                              │          │    │  │
│  │  │  │ ─────────────────────────────────────────  │          │    │  │
│  │  │  │                                            │          │    │  │
│  │  │  │ Category Badge: [📋 Requirements]          │          │    │  │
│  │  │  │                                            │          │    │  │
│  │  │  │ Question Title                             │          │    │  │
│  │  │  │ "What is your primary use case?"           │          │    │  │
│  │  │  │                                            │          │    │  │
│  │  │  │ Help Text                                  │          │    │  │
│  │  │  │ ℹ️ "Select the main capability you need"   │          │    │  │
│  │  │  │                                            │          │    │  │
│  │  │  │ Input Area                                 │          │    │  │
│  │  │  │ ┌────────────────────────────────┐        │          │    │  │
│  │  │  │ │ ○ Code Generation              │        │          │    │  │
│  │  │  │ │ ○ Creative Writing             │        │          │    │  │
│  │  │  │ │ ● Data Analysis ✓              │        │          │    │  │
│  │  │  │ │ ○ Customer Service             │        │          │    │  │
│  │  │  │ │ ○ Process Automation           │        │          │    │  │
│  │  │  │ │ ○ Research & Knowledge         │        │          │    │  │
│  │  │  │ └────────────────────────────────┘        │          │    │  │
│  │  │  │                                            │          │    │  │
│  │  │  └────────────────────────────────────────────┘          │    │  │
│  │  │                                                           │    │  │
│  │  │  Navigation:                                              │    │  │
│  │  │  [← Previous]  [Skip]  [Next Question →]                 │    │  │
│  │  │                                                           │    │  │
│  │  │  Progress: ████████░░░░░░░░░░ 45%                        │    │  │
│  │  │  Question 5 of 11                                         │    │  │
│  │  │                                                           │    │  │
│  │  └───────────────────────────────────────────────────────────┘    │  │
│  │                                                                     │  │
│  │  ┌───────────────────────────────────────────────────────────┐    │  │
│  │  │                 RESULTS DISPLAY                           │    │  │
│  │  │                                                           │    │  │
│  │  │  ✨ Your Personalized Recommendations                     │    │  │
│  │  │  Based on 11 answers                                      │    │  │
│  │  │                                                           │    │  │
│  │  │  🏆 Top 3 Recommendations                                 │    │  │
│  │  │  ┌────────────┬────────────┬────────────┐               │    │  │
│  │  │  │            │            │            │               │    │  │
│  │  │  │ 🏆 #1      │  🥈 #2     │  🥉 #3     │               │    │  │
│  │  │  │ Best Match │            │            │               │    │  │
│  │  │  │            │            │            │               │    │  │
│  │  │  │ Microsoft  │  ChatGPT   │  Claude    │               │    │  │
│  │  │  │ Copilot    │  Enterprise│            │               │    │  │
│  │  │  │            │            │            │               │    │  │
│  │  │  │ 🟢 92%     │  🔵 87%    │  🔵 84%    │               │    │  │
│  │  │  │ Match      │  Match     │  Match     │               │    │  │
│  │  │  │            │            │            │               │    │  │
│  │  │  │ Confidence:│ Confidence:│ Confidence:│               │    │  │
│  │  │  │ ▓▓▓▓▓ 88%  │ ▓▓▓▓░ 82%  │ ▓▓▓▓░ 79%  │               │    │  │
│  │  │  │            │            │            │               │    │  │
│  │  │  │ Breakdown: │ Breakdown: │ Breakdown: │               │    │  │
│  │  │  │ Requirements│Requirements│Requirements│               │    │  │
│  │  │  │ 94%        │ 89%        │ 87%        │               │    │  │
│  │  │  │ Constraints│ Constraints│ Constraints│               │    │  │
│  │  │  │ 90%        │ 85%        │ 82%        │               │    │  │
│  │  │  │ Priorities │ Priorities │ Priorities │               │    │  │
│  │  │  │ 92%        │ 87%        │ 83%        │               │    │  │
│  │  │  │            │            │            │               │    │  │
│  │  │  │ ✅ Strengths│ ✅ Strengths│ ✅ Strengths│               │    │  │
│  │  │  │ • Excellent│ • Great for│ • Strong   │               │    │  │
│  │  │  │   for data │   code gen │   reasoning│               │    │  │
│  │  │  │ • Native   │ • Fast impl│ • Excellent│               │    │  │
│  │  │  │   Microsoft│ • Large    │   creative │               │    │  │
│  │  │  │   365      │   context  │            │               │    │  │
│  │  │  │            │            │            │               │    │  │
│  │  │  │ ⚠️ Concerns │ ⚠️ Concerns │ ⚠️ Concerns │               │    │  │
│  │  │  │ • Premium  │ • Price 15%│ • Smaller  │               │    │  │
│  │  │  │   pricing  │   over bdgt│   market   │               │    │  │
│  │  │  │            │            │   share    │               │    │  │
│  │  │  │ ⭐ Unique  │ ⭐ Unique  │ ⭐ Unique  │               │    │  │
│  │  │  │ • Baseline │ • Market   │ • Best for │               │    │  │
│  │  │  │   choice   │   leader   │   thinking │               │    │  │
│  │  │  │            │            │            │               │    │  │
│  │  │  │ [Details ▼]│ [Details ▼]│ [Details ▼]│               │    │  │
│  │  │  └────────────┴────────────┴────────────┘               │    │  │
│  │  │                                                           │    │  │
│  │  │  Other Platforms Considered (13 more)                     │    │  │
│  │  │  ┌─────────────────────────────────────────────────┐    │    │  │
│  │  │  │ #4  Google Gemini         Match: 79%  [$30/mo] │    │    │  │
│  │  │  │ #5  Claude Pro            Match: 76%  [$20/mo] │    │    │  │
│  │  │  │ #6  GitHub Copilot        Match: 73%  [$10/mo] │    │    │  │
│  │  │  │ ...                                             │    │    │  │
│  │  │  └─────────────────────────────────────────────────┘    │    │  │
│  │  │                                                           │    │  │
│  │  │  🎯 Recommended Next Steps                               │    │  │
│  │  │  1️⃣ Review Top 3 Platforms                              │    │  │
│  │  │  2️⃣ Run ROI Calculations                                │    │  │
│  │  │  3️⃣ Request Demos                                        │    │  │
│  │  │  4️⃣ Assess Organizational Readiness                     │    │  │
│  │  │                                                           │    │  │
│  │  │  [💰 Calculate ROI] [📊 Compare] [📥 Export Report]      │    │  │
│  │  │  [🔄 Start New Recommendation]                           │    │  │
│  │  └───────────────────────────────────────────────────────────┘    │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## 🧩 Component Hierarchy

```
RecommendationWizard
├── Header
│   ├── Icon & Title
│   ├── Progress Bar (0-100%)
│   ├── Question Counter (X of 11)
│   └── Close Button (optional)
│
├── QuestionCard (current question)
│   ├── Category Badge
│   │   ├── 📋 Requirements (orange)
│   │   ├── ⚠️ Constraints (yellow)
│   │   └── ⭐ Priorities (purple)
│   │
│   ├── Question Text
│   ├── Help Text (ℹ️ icon)
│   │
│   └── Input Component (dynamic)
│       ├── SingleSelect (radio cards)
│       ├── MultiSelect (checkbox cards)
│       ├── RangeSlider (with quick buttons)
│       ├── Boolean (yes/no cards)
│       └── Priority (drag-drop list)
│
├── Navigation Controls
│   ├── [← Previous] (disabled on Q1)
│   ├── [Skip] (always enabled)
│   └── [Next →] or [Get Recommendations]
│       └── (disabled until answered/skipped)
│
└── Visual Indicators
    ├── Progress Dots (11 dots)
    │   ├── Green: Completed
    │   ├── Orange: Current
    │   └── Gray: Not yet answered
    └── Category Badge (below nav)

RecommendationResults
├── Header
│   ├── Title & Summary
│   ├── Action Buttons
│   │   ├── 📥 Export (JSON)
│   │   └── 🔄 Restart
│   └── Close Button (optional)
│
├── Top 3 Recommendations
│   └── For each (3 cards):
│       ├── Rank Badge (#1, #2, #3)
│       ├── Best Match Badge (only #1)
│       ├── Platform Header
│       │   ├── Logo Emoji
│       │   ├── Name & Provider
│       │   └── Rank Circle
│       │
│       ├── Match Score
│       │   ├── Percentage (0-100%)
│       │   ├── Color-coded
│       │   └── Progress Bar
│       │
│       ├── Confidence Indicator
│       │   ├── Percentage Bar
│       │   └── Text Label
│       │
│       ├── Breakdown Scores
│       │   ├── Requirements %
│       │   ├── Constraints %
│       │   └── Priorities %
│       │
│       ├── Quick Info Grid
│       │   ├── Pricing
│       │   ├── Market Share
│       │   ├── Implementation Time
│       │   └── Compliance Count
│       │
│       ├── [Show Details ▼] Button
│       │
│       └── Expandable Details
│           ├── ✅ Strengths (up to 5)
│           ├── ⚠️ Concerns (up to 4)
│           ├── ⭐ Differentiators (up to 3)
│           └── Platform Description
│
├── Other Platforms List
│   └── Compact cards showing:
│       ├── Rank #
│       ├── Logo & Name
│       ├── Match Score
│       └── Price + Impl Time
│
└── Next Steps Section
    ├── 4-step guidance
    └── Action buttons
        ├── [💰 Calculate ROI]
        ├── [📊 Compare Platforms]
        ├── [📥 Export Report]
        └── [🔄 Start Over]
```

---

## 🎨 Design System

### Color Palette

```
Primary:
  #E88A1D - Orange (brand primary)
  #D97706 - Dark orange (gradients)
  #FEF3E7 - Light orange (backgrounds)

Status Colors:
  🟢 #059669 - Excellent (90-100%)
  🔵 #3B82F6 - Good (75-89%)
  🟡 #F59E0B - Fair (60-74%)
  🔴 #DC2626 - Poor (<60%)

Categories:
  📋 #1E40AF - Requirements (blue)
  ⚠️ #92400E - Constraints (amber)
  ⭐ #6B21A8 - Priorities (purple)

Neutrals:
  #231C19 - Text primary
  #5C524D - Text secondary
  #8B8279 - Text tertiary
  #EDE8E3 - Border
  #FAFAFA - Background light
  #FFFCF8 - Background primary
```

### Typography

```
Headers:
  H1: 36-48px, Font Serif, #231C19
  H2: 24-32px, Font Serif, #231C19
  H3: 18-20px, Font Semibold, #231C19

Body:
  Regular: 14-16px, #231C19
  Small: 12-14px, #5C524D
  Tiny: 10-12px, #8B8279

Special:
  Match Score: 32-36px, Font Serif, Color-coded
  Percentage: 18-24px, Font Serif, #E88A1D
```

### Spacing

```
Container:
  Max Width: 1200px (results), 900px (wizard)
  Padding: 24px (mobile), 48px (desktop)

Cards:
  Padding: 24px
  Gap: 16-24px
  Border Radius: 12-16px

Sections:
  Vertical Gap: 32-48px
  Component Gap: 16-24px
```

### Animations

```
Page Transitions:
  Duration: 300ms
  Easing: ease-in-out
  Type: Slide + Fade

Progress Bar:
  Duration: 300ms
  Easing: ease-out
  Type: Width animation

Results Entrance:
  Duration: 200ms each
  Delay: 100ms stagger
  Type: Fade + Scale

Expand/Collapse:
  Duration: 200ms
  Easing: ease
  Type: Height + Opacity
```

---

## 📊 Data Flow Diagram

```
┌─────────────────┐
│   User Input    │
│  (11 Questions) │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  UserAnswers    │
│   { q1: {...},  │
│     q2: {...},  │
│     ... }       │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────────────────┐
│    recommendationEngine.ts                  │
│  calculateRecommendations()                 │
│                                             │
│  ┌────────────────────────────────────┐   │
│  │ For each platform (16+):           │   │
│  │                                    │   │
│  │ 1. Calculate Requirements Score    │   │
│  │    ├─ Use case alignment          │   │
│  │    ├─ Team size matching          │   │
│  │    └─ Integration support         │   │
│  │                                    │   │
│  │ 2. Calculate Constraints Score     │   │
│  │    ├─ Budget validation           │   │
│  │    ├─ Compliance check            │   │
│  │    ├─ Ecosystem fit               │   │
│  │    └─ Data residency              │   │
│  │                                    │   │
│  │ 3. Calculate Priorities Score      │   │
│  │    ├─ Capability ranking          │   │
│  │    ├─ Implementation speed        │   │
│  │    ├─ Context window              │   │
│  │    └─ Market preference           │   │
│  │                                    │   │
│  │ 4. Weighted Total                  │   │
│  │    Total = (Req × 0.4) +          │   │
│  │            (Con × 0.4) +          │   │
│  │            (Pri × 0.2)            │   │
│  │                                    │   │
│  │ 5. Confidence Score                │   │
│  │    Base 80% ± adjustments         │   │
│  │                                    │   │
│  │ 6. Generate Reasoning              │   │
│  │    ├─ Strengths                   │   │
│  │    ├─ Concerns                    │   │
│  │    └─ Differentiators             │   │
│  │                                    │   │
│  └────────────────────────────────────┘   │
│                                             │
│  7. Sort by Total Score (desc)             │
│  8. Assign Ranks (1-16)                    │
└───────────────┬─────────────────────────────┘
                │
                ▼
┌───────────────────────────────────┐
│  RecommendationScore[]            │
│  [                                │
│    {                              │
│      platform: Platform,          │
│      totalScore: 92,              │
│      confidence: 88,              │
│      matchBreakdown: {            │
│        requirements: 94,          │
│        constraints: 90,           │
│        priorities: 92             │
│      },                           │
│      reasons: {                   │
│        strengths: [...],          │
│        concerns: [...],           │
│        differentiators: [...]     │
│      },                           │
│      rank: 1                      │
│    },                             │
│    ...                            │
│  ]                                │
└────────────┬──────────────────────┘
             │
             ▼
┌─────────────────────────────┐
│  RecommendationResults      │
│  Display Component          │
│                             │
│  • Top 3 highlighted        │
│  • Full list ranked         │
│  • Export option            │
│  • Next steps               │
└─────────────────────────────┘
```

---

## 🎯 Scoring Algorithm Visual

```
┌──────────────────────────────────────────────────────────────┐
│                   TOTAL SCORE CALCULATION                    │
│                                                              │
│  ┌────────────────┐   ┌────────────────┐   ┌─────────────┐ │
│  │  Requirements  │   │  Constraints   │   │  Priorities │ │
│  │    Score       │   │     Score      │   │    Score    │ │
│  │    0-100       │   │     0-100      │   │    0-100    │ │
│  └───────┬────────┘   └───────┬────────┘   └──────┬──────┘ │
│          │                    │                    │        │
│          │ × 0.4              │ × 0.4              │ × 0.2  │
│          │                    │                    │        │
│          ▼                    ▼                    ▼        │
│         40%                  40%                  20%       │
│          └────────────────────┴────────────────────┘        │
│                              │                              │
│                              ▼                              │
│                      ┌───────────────┐                      │
│                      │  TOTAL SCORE  │                      │
│                      │    0-100      │                      │
│                      └───────────────┘                      │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                   REQUIREMENTS BREAKDOWN                     │
│                      (40% of total)                          │
│                                                              │
│  Primary Use Case        ━━━━━━━━━━ 100%   Weight: 1.0     │
│  Team Size Match         ━━━━━━━━░░  80%   Weight: 0.8     │
│  Integration Support     ━━━━━━━░░░  70%   Weight: 0.7     │
│                                                              │
│  Weighted Average: 85%                                       │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                   CONSTRAINTS BREAKDOWN                      │
│                      (40% of total)                          │
│                                                              │
│  Start: 100%                                                 │
│                                                              │
│  Budget Overage          -15%  ($40 vs $30 budget)          │
│  Missing Compliance      -30%  (2 certs × 15pts)            │
│  Ecosystem Bonus         +10%  (Native integration)         │
│  Data Residency          -0%   (Supported)                  │
│                                                              │
│  Final: 65%                                                  │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                   PRIORITIES BREAKDOWN                       │
│                      (20% of total)                          │
│                                                              │
│  Capability Priorities   ━━━━━━━━░░  80%   Weight: 0.6     │
│  Implementation Speed    ━━━━━━━━━░  90%   Weight: 0.5     │
│  Context Window Need     ━━━━━━━░░░  70%   Weight: 0.4     │
│  Market Leader Pref      ━━━━━━━━━━ 100%   Weight: 0.3     │
│                                                              │
│  Weighted Average: 84%                                       │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                   CONFIDENCE CALCULATION                     │
│                                                              │
│  Base Confidence         ━━━━━━━━░░  80%                    │
│                                                              │
│  Adjustments:                                                │
│    High avg score (85+)  +10%                                │
│    Low constraints       -15%  (< 60%)                       │
│    Established platform  +5%   (Market share > 20%)         │
│    Complete answers      +5%   (≥ 10 questions)             │
│                                                              │
│  Final Confidence:       ━━━━━━━━░░  85%                    │
└──────────────────────────────────────────────────────────────┘
```

---

## 📱 Responsive Breakpoints

```
Mobile First Design:

320px - 640px      (Mobile)
├─ Single column layout
├─ Full width cards
├─ Stacked navigation
└─ Simplified progress bar

640px - 1024px     (Tablet)
├─ 2-column grid for top 3
├─ Wider cards
├─ Full navigation visible
└─ Enhanced progress display

1024px+            (Desktop)
├─ 3-column grid for top 3
├─ Max width containers
├─ Hover effects enabled
└─ Full feature set

Max Width: 1200px (results), 900px (wizard)
```

---

**Visual Feature Map Version:** 1.0  
**Last Updated:** December 2025  
**Maintained by:** INT Inc. Design Team
