# INT Inc Enterprise Claude Profile Builder

A production-ready, data-driven documentation platform for enterprise Claude AI deployment. Built with React 18, TypeScript, and Tailwind CSS v4.

## 🎯 Overview

The Enterprise Profile Builder provides comprehensive documentation for deploying and managing Claude AI in enterprise environments. It includes role-based guidance, feature documentation, security controls, and compliance tracking.

**Original Design**: [Figma Design](https://www.figma.com/design/BxL9KerTYKvxWcSTvaoXPn/Enterprise-Profile-Builder)

## ✨ Key Features

- **📊 Role-Based Documentation** - Tailored guidance for Finance, Sales, Engineering, Marketing, Operations, and HR
- **🔍 Advanced Search** - Fuzzy search across FAQs, features, tools, and role profiles
- **🔐 Security Architecture** - OWASP LLM Top 10 controls, prompt injection defense (6 layers)
- **📋 Deployment Checklist** - Interactive progress tracking for implementation
- **🏛️ Compliance Ready** - EU AI Act tracking, SOC 2, GDPR, HIPAA ready
- **♿ Accessible** - WCAG 2.1 AA compliant with Radix UI primitives
- **⌨️ Keyboard Shortcuts** - Ctrl+K for search, / for quick search, Escape to close

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

The development server runs at `http://localhost:3000`

## 📁 Project Structure

```
src/
├── components/          # 64 React components
│   ├── ui/             # 45 Radix-based UI primitives
│   ├── sections/       # 8 content sections
│   └── figma/          # Figma integration components
├── data/               # Content data (role profiles, FAQs, features)
├── hooks/              # Custom React hooks (3)
├── utils/              # Utility functions (search, storage, analytics)
├── lib/                # Core library (constants, errors, logger)
├── config/             # Application configuration
├── security/           # Prompt injection defense system
├── compliance/         # EU AI Act compliance tracker
├── types/              # TypeScript type definitions
└── docs/               # Technical documentation suite
```

## 📚 Documentation Suite

| Document | Description |
|----------|-------------|
| [ARCHITECTURE.md](src/docs/ARCHITECTURE.md) | System architecture and design patterns |
| [API.md](src/docs/API.md) | Component and hook API reference |
| [SECURITY.md](src/SECURITY.md) | Security policy and controls |
| [DEPLOYMENT.md](src/docs/DEPLOYMENT.md) | Deployment guide |
| [TESTING.md](src/docs/TESTING.md) | Testing strategy and examples |
| [PHASES.md](src/docs/PHASES.md) | Development phases and tasks |
| [AUDIT_REPORT.md](src/docs/AUDIT_REPORT.md) | Comprehensive codebase audit |
| [INDEX.md](src/docs/INDEX.md) | Full documentation index |

## 🛡️ Security Features

### 6-Layer Security Architecture

1. **Rate Limiting** - 20 requests/minute, anomaly detection
2. **Input Validation** - Pattern matching, encoding detection
3. **Injection Detection** - 7 pattern categories (instruction override, role manipulation, etc.)
4. **Semantic Analysis** - Instruction override detection
5. **Human-in-the-Loop** - High/Critical risk review
6. **Structural Isolation** - Security boundaries for prompts

### Compliance

- **EU AI Act** - Full compliance tracking system
- **SOC 2 Type II** - Access control, encryption, audit logging
- **GDPR** - Data minimization, right to erasure
- **HIPAA** - No PII storage, secure architecture
- **WCAG 2.1 AA** - Full accessibility compliance

## 📊 Tech Stack

| Category | Technology | Version |
|----------|------------|---------|
| Framework | React | 18.3.1 |
| Language | TypeScript | 5+ |
| Build Tool | Vite (SWC) | 6.3.5 |
| Styling | Tailwind CSS | v4.1.3 |
| UI Components | Radix UI | 28 primitives |
| Icons | Lucide React | 0.487.0 |
| Charts | Recharts | 2.15.2 |
| Forms | React Hook Form | 7.55.0 |

## 🧪 Testing

```bash
# Run tests
npm test
```

Current test coverage:
- Security tests: ✅ Comprehensive
- Unit tests: 🔄 In progress

## 📈 Codebase Metrics

| Metric | Value |
|--------|-------|
| TypeScript Files | 102 |
| Components | 64 |
| Custom Hooks | 3 |
| Lines of Code | ~10,000 |
| Documentation Files | 14 |
| Documentation Lines | ~15,000 |

## 🗂️ Content Sections

1. **Overview** - Welcome and key features
2. **Baseline Prompt** - System prompt documentation
3. **Feature Guides** - Web Search, Memory, Artifacts, Code, Files
4. **Tools & Connectors** - MCP server catalog
5. **Role Profiles** - 7 department-specific guides
6. **Best Practices** - Usage recommendations
7. **FAQ** - Searchable, filterable questions
8. **Deployment** - Implementation checklist

## 🔧 Configuration

Configuration is centralized in `src/config/app.config.ts`:

- Feature flags (search, bookmarks, analytics, shortcuts)
- Performance settings (debounce, max results, toast duration)
- Security settings (CSP, rate limits, file restrictions)
- UI settings (breakpoints, colors, typography)

## 📄 License

Proprietary - INT Inc. All rights reserved.

---

**Version**: 1.0.0 | **Last Updated**: December 21, 2025 | **Audit Status**: ✅ Passed
